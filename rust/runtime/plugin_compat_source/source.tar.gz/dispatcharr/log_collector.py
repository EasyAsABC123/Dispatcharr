"""Everything logger: the container's merged stdout flows through this
process, which forwards each normalized line to the real stdout for docker
logs and files the same bytes, so both sinks carry the same record.

Runs standalone (python -m dispatcharr.log_collector <logdir>); no application
process ever performs log file I/O. The reader owns stdin from the first
instant and touches only stdout, so a dead /data can never back-pressure the
producers; bounded memory with drop-oldest and an explicit dropped-lines
marker absorbs disk stalls (markers are file-only: the forwarded stream never
dropped anything). Every line is rewritten into the canonical
"stamp [offset] LEVEL source rest" grammar. Owns rotation and pruning.
Django-free; configured via <logdir>/config/collector.conf from apply_settings().
"""

import collections
import logging
import os
import re
import signal
import sys
import threading
import time
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo


def _role_suffix():
    # The role reaches a filesystem path, so it is sanitized rather than trusted.
    role = re.sub(r"[^A-Za-z0-9]", "", os.environ.get("DISPATCHARR_LOG_ROLE", ""))
    return f"-{role[:16]}" if role else ""


_SUFFIX = _role_suffix()
BASE_NAME = "dispatcharr.log"
LIVE_NAME = f"{BASE_NAME}{_SUFFIX}"
# Shared: one settings save configures every collector on this log directory.
CONF_NAME = "collector.conf"
PID_NAME = f"collector{_SUFFIX}.pid"

# Live file, optional role suffix, optional rotation index. Used by the log
# browser so a rename here cannot silently empty the page, and a near-prefix
# name in the same directory cannot be served.
_LOG_FAMILY_RE = re.compile(
    rf"^{re.escape(BASE_NAME)}(-[A-Za-z0-9]{{1,16}})?(\.\d+)?$"
)


def is_log_family_name(name):
    """Whether *name* is a collector live or rotated log file."""
    return bool(_LOG_FAMILY_RE.fullmatch(name))

_FLUSH_INTERVAL_SECONDS = 0.25
_BATCH_BYTES = 128 * 1024
_BUFFER_BYTES = 2 * 1024 * 1024
_MAX_LINE_BYTES = 256 * 1024
_MAX_RECORD_BYTES = 16 * 1024

_TRUNCATED = b" ... [log_collector truncated this record at %d bytes]\n" % _MAX_RECORD_BYTES

DEFAULT_LOG_MB = 5
MAX_LOG_MB = 20
DEFAULT_LOG_KEEP = 5
MAX_LOG_KEEP = 50

_DEFAULT_CONF = {
    "persist": True,
    "max_mb": DEFAULT_LOG_MB,
    "keep": DEFAULT_LOG_KEEP,
    "time_zone": "",
}

# One canonical shape for every source: "stamp [offset] LEVEL source rest".
_CANON = re.compile(rb"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3} [+-]\d{4} ")
_REDIS_LEVELS = {b".": b"DEBUG", b"-": b"DEBUG", b"*": b"INFO", b"#": b"WARNING"}
# Postgres repeats its prefix on DETAIL/HINT/STATEMENT, so those arrive as
# stamped lines that belong to the severity above them.
_PG_SEVERITY = re.compile(rb"^([A-Z]+)\d*:")
_PG_LEVELS = {
    b"DEBUG": b"DEBUG",
    b"LOG": b"INFO",
    b"INFO": b"INFO",
    b"NOTICE": b"INFO",
    b"WARNING": b"WARNING",
    b"ERROR": b"ERROR",
    b"FATAL": b"CRITICAL",
    b"PANIC": b"CRITICAL",
}
_NGX_LEVELS = {
    b"debug": b"DEBUG",
    b"info": b"INFO",
    b"notice": b"INFO",
    b"warn": b"WARNING",
    b"error": b"ERROR",
    b"crit": b"CRITICAL",
    b"alert": b"CRITICAL",
    b"emerg": b"CRITICAL",
}
# uwsgi's request log-format mimics the Python shape but stamps localtime.
_PY_REQ = re.compile(
    rb"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}),(\d{3}) (\S+ uwsgi\.requests )"
)
_PY = re.compile(rb"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}),(\d{3}) (?!- )")
_UWSGI = re.compile(rb"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}),(\d{3}) - ")
_SHELL = re.compile(rb"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) - ")
_REDIS = re.compile(
    rb"^(\d+:[MCSX]) (\d{1,2} \w{3} \d{4} \d{2}:\d{2}:\d{2})\.(\d{3}) "
)
_PG = re.compile(
    rb"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\.(\d{3}) ([A-Za-z0-9+\-]{2,5}) (\[\d+\] )"
)
_NGX_ERR = re.compile(rb"^(\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2}) (\[\w+\] )")
_NGX_ACC = re.compile(
    rb"^((?:\d{1,3}\.){3}\d{1,3} \S+ \S+) "
    rb"\[(\d{2}/\w{3}/\d{4}:\d{2}:\d{2}:\d{2}) ([+-]\d{4})\] "
)
_CONTINUATION = re.compile(rb"^[ \t]")
_TB_START = re.compile(rb"^Traceback")


def _boot_display_zone():
    """The display zone to stamp in until the app's setting arrives.

    The collector starts under `su -`, which strips TZ, and the image ships
    /etc/localtime as UTC, so the environment variable the entrypoint puts in
    the login profile is the only zone this process can see before its first
    conf read. It is the same value the system time zone is seeded from, so
    the boot lines and the lines after the first conf read agree.
    """
    return _env_tz_zone() or timezone.utc


def _env_tz_zone():
    """The entrypoint's mirror of TZ, whitelisted through `su -`, or None."""
    name = os.environ.get("DISPATCHARR_TIME_ZONE", "").strip()
    if name:
        try:
            return ZoneInfo(name)
        except (KeyError, ValueError):
            pass
    return None


def _cap_record(line):
    """Cut an oversize record for the file, never through a codepoint.

    The tail is served as text/plain; charset=utf-8 and downloaded verbatim, so
    a cut inside a multi-byte sequence would make the file itself malformed.
    """
    cut = _MAX_RECORD_BYTES
    while cut > 0 and (line[cut] & 0xC0) == 0x80:
        cut -= 1
    return line[:cut] + _TRUNCATED


def _resolve_container_zone():
    # The zone libc-stamping daemons use.
    try:
        name = os.readlink("/etc/localtime").split("zoneinfo/", 1)[1]
        return ZoneInfo(name)
    except (OSError, IndexError, KeyError, ValueError):
        pass
    try:
        # Bind-mounted /etc/localtime is a plain file; stay DST-aware.
        with open("/etc/localtime", "rb") as f:
            return ZoneInfo.from_file(f)
    except (OSError, ValueError):
        pass
    try:
        return datetime.now().astimezone().tzinfo or timezone.utc
    except Exception:
        return timezone.utc


def _resolve_pid1_zone(default):
    # nginx and the entrypoint honour TZ; the entrypoint mirrors it here.
    return _env_tz_zone() or default


def _config_dir(log_dir):
    # Out of the log files' way: the directory's top level holds only logs.
    return os.path.join(log_dir, "config")


def conf_path(log_dir):
    return os.path.join(_config_dir(log_dir), CONF_NAME)


def pid_path(log_dir):
    return os.path.join(_config_dir(log_dir), PID_NAME)


def write_conf(log_dir, persist, max_mb, keep, time_zone="UTC"):
    """Write collector.conf atomically; called from the app (safe contexts only)."""
    if not log_dir:
        return
    # Pids repeat across containers sharing the directory; the role does not.
    tmp = f"{conf_path(log_dir)}.tmp{_SUFFIX}.{os.getpid()}"
    try:
        os.makedirs(_config_dir(log_dir), exist_ok=True)
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(
                f"persist={1 if persist else 0}\n"
                f"max_mb={int(max_mb)}\n"
                f"keep={int(keep)}\n"
                f"time_zone={time_zone}\n"
            )
        os.replace(tmp, conf_path(log_dir))
    except OSError:
        pass


def apply_settings(log_dir, values, warn_if_absent=False):
    """Push the system-settings log keys to the collector's conf.

    Runs on settings saves and process boot — rare, small writes. Every
    collector on this log directory notices the write within a tick.
    """
    values = values or {}
    write_conf(
        log_dir,
        values.get("log_persist", True) is not False,
        values.get("log_max_mb", DEFAULT_LOG_MB) or DEFAULT_LOG_MB,
        values.get("log_keep", DEFAULT_LOG_KEEP) or DEFAULT_LOG_KEEP,
        values.get("time_zone") or "UTC",
    )
    if warn_if_absent and not collector_running(log_dir):
        logging.getLogger(__name__).warning(
            "Log settings saved, but no log collector is running to apply them; "
            "process output is unaffected and the log file is not being written."
        )


def collector_pid(log_dir):
    """The running collector's pid, or None.

    A pidfile alone proves nothing: the process it names may be gone or, worse,
    recycled onto something else, so the cmdline has to say log_collector.
    """
    if not log_dir:
        return None
    try:
        with open(pid_path(log_dir), encoding="utf-8") as f:
            pid = int(f.read().strip())
        with open(f"/proc/{pid}/cmdline", "rb") as f:
            cmdline = f.read()
        # Match the entrypoint's invocation, not a bare mention in another process's args.
        if not any(
            token in cmdline
            for token in (b"dispatcharr.log_collector", b"log_collector.py")
        ):
            return None
    except (OSError, ValueError):
        return None
    return pid


def collector_running(log_dir):
    """Whether a collector runs in this container."""
    return collector_pid(log_dir) is not None


def read_conf(log_dir):
    conf = dict(_DEFAULT_CONF)
    try:
        with open(conf_path(log_dir), encoding="utf-8") as f:
            for line in f:
                key, sep, value = line.strip().partition("=")
                if sep and key in conf:
                    conf[key] = value
    except OSError:
        return conf
    conf["persist"] = str(conf["persist"]).strip() not in ("0", "false", "")
    for key, lo, cap in (("max_mb", 1, MAX_LOG_MB), ("keep", 2, MAX_LOG_KEEP)):
        try:
            conf[key] = min(max(int(conf[key]), lo), cap)
        except (TypeError, ValueError):
            conf[key] = _DEFAULT_CONF[key]
    return conf


class _WriteFailure(Exception):
    def __init__(self, written, cause):
        super().__init__(cause)
        self.written = written
        self.cause = cause


class Collector:
    def __init__(self, log_dir, out_fd=1):
        self.log_dir = log_dir
        self.out_fd = out_fd
        self.live_path = os.path.join(log_dir, LIVE_NAME)
        self._buf = collections.deque()
        self._buf_bytes = 0
        self._dropped = 0
        self._lock = threading.Lock()
        self._wake = threading.Event()
        self._stop = False
        self._reload = True
        self._fd = None
        self._tail_open = False
        self._fs_ready = False
        self._conf_stamp = None
        self._continuation = False
        self._in_traceback = False
        self._pg_level = b"INFO"
        self.conf = dict(_DEFAULT_CONF)
        self._display_zone = _boot_display_zone()
        self._container_zone = timezone.utc
        self._pid1_zone = timezone.utc

    def install_signals(self):
        # The handler sets a plain flag only: threading primitives are not signal-safe.
        signal.signal(signal.SIGTERM, lambda *_: setattr(self, "_stop", True))

    # ── reader thread: stdin -> normalize -> gate -> forward -> buffer ────

    def reader(self, stream):
        mid_line = False
        overrun = False
        while True:
            chunk = stream.readline(_MAX_LINE_BYTES)
            if not chunk:
                break
            more = not chunk.endswith(b"\n")
            # Continuation chunks of an oversize line must not be stamped.
            tail = mid_line
            if mid_line:
                line = chunk
            else:
                line = self._normalize(chunk)
                # One runaway record can evict a rotation of history, so only the
                # file copy is capped; docker logs takes the record whole.
                overrun = len(line) > _MAX_RECORD_BYTES
            mid_line = more
            self._forward(line)
            if overrun:
                if tail:
                    # The file already carries this record's marker.
                    continue
                line = _cap_record(line)
            if not self.conf["persist"]:
                # Keep forwarding; only the file sink honours the toggle.
                continue
            with self._lock:
                while self._buf_bytes + len(line) > _BUFFER_BYTES and self._buf:
                    old = self._buf.popleft()
                    self._buf_bytes -= len(old)
                    self._dropped += 1
                self._buf.append(line)
                self._buf_bytes += len(line)
                over = self._buf_bytes >= _BATCH_BYTES
            if over:
                self._wake.set()
        self._stop = True
        self._wake.set()

    def _render(self, dt):
        # Every line pays for this call, so it's field access and f-string
        # padding instead of strftime; utcoffset() beats a second strftime
        # call for the zone suffix. Both agree with strftime for any real
        # (post-1970) timestamp; they only part ways on pre-standard-zone
        # LMT offsets, which a container's clock can never produce.
        dt = dt.astimezone(self._display_zone)
        base = (
            f"{dt.year:04d}-{dt.month:02d}-{dt.day:02d} "
            f"{dt.hour:02d}:{dt.minute:02d}:{dt.second:02d},{dt.microsecond // 1000:03d}"
        )
        off = dt.utcoffset()
        if off and off != timedelta():
            total_min = int(off.total_seconds() // 60)
            sign = "+" if total_min >= 0 else "-"
            total_min = abs(total_min)
            return f"{base} {sign}{total_min // 60:02d}{total_min % 60:02d}"
        return base

    def _now_stamp(self):
        return self._render(datetime.now(timezone.utc))

    def _zone_for_token(self, token, stamp):
        # Postgres carries its own log_timezone: match the abbreviation it stamps
        # against the zones this container knows before assuming the clock.
        if token in (b"UTC", b"GMT"):
            return timezone.utc
        try:
            name = token.decode()
            naive = datetime.strptime(stamp.decode(), "%Y-%m-%d %H:%M:%S")
            for zone in (self._display_zone, self._pid1_zone, self._container_zone):
                if naive.replace(tzinfo=zone).tzname() == name:
                    return zone
        except Exception:
            pass
        return self._container_zone

    def _parse_naive(self, stamp, ms, zone, fmt="%Y-%m-%d %H:%M:%S"):
        if fmt == "%Y-%m-%d %H:%M:%S" and len(stamp) == 19:
            # Fixed-width ISO stamps dominate the stream; int slices beat strptime.
            y = int(stamp[0:4])
            mo = int(stamp[5:7])
            d = int(stamp[8:10])
            h = int(stamp[11:13])
            mi = int(stamp[14:16])
            s = int(stamp[17:19])
            return datetime(y, mo, d, h, mi, s, ms * 1000, tzinfo=zone)
        dt = datetime.strptime(stamp.decode(), fmt)
        return dt.replace(microsecond=ms * 1000, tzinfo=zone)

    def _normalize(self, raw):
        """Classify *raw* as a record or a continuation and canonicalise records."""
        out = self._restamp(raw)
        if out is not None:
            self._continuation = False
            self._in_traceback = False
            return out
        if _TB_START.match(raw):
            self._continuation = True
            self._in_traceback = True
            return raw
        # _restamp runs first so the stream recovers after a traceback.
        if self._in_traceback or _CONTINUATION.match(raw):
            self._continuation = True
            return raw
        self._continuation = False
        return f"{self._now_stamp()} INFO stdout ".encode() + raw

    def _restamp(self, raw):
        """Rewrite a known source into "stamp [offset] LEVEL source rest", else None.

        Strict match or pass through: an unrecognised line is never altered,
        so a parse surprise cannot garble the stream. Native severity text
        stays verbatim in the body; only the stamp and tokens are synthetic.
        """
        try:
            if _CANON.match(raw):
                return raw
            m = _PY_REQ.match(raw)
            if m:
                dt = self._parse_naive(m.group(1), int(m.group(2)), self._container_zone)
                return f"{self._render(dt)} ".encode() + m.group(3) + raw[m.end() :]
            m = _PY.match(raw)
            if m:
                dt = self._parse_naive(m.group(1), int(m.group(2)), timezone.utc)
                return f"{self._render(dt)} ".encode() + raw[m.end() :]
            m = _UWSGI.match(raw)
            if m:
                dt = self._parse_naive(m.group(1), int(m.group(2)), self._container_zone)
                return f"{self._render(dt)} INFO uwsgi ".encode() + raw[m.end() :]
            m = _SHELL.match(raw)
            if m:
                dt = self._parse_naive(m.group(1), 0, self._pid1_zone)
                return f"{self._render(dt)} INFO entrypoint ".encode() + raw[m.end() :]
            m = _REDIS.match(raw)
            if m:
                dt = self._parse_naive(
                    m.group(2), int(m.group(3)), self._container_zone, "%d %b %Y %H:%M:%S"
                )
                rest = raw[m.end() :]
                level = _REDIS_LEVELS.get(rest[:1], b"INFO")
                return (
                    f"{self._render(dt)} ".encode()
                    + level
                    + b" redis "
                    + m.group(1)
                    + b" "
                    + rest
                )
            m = _PG.match(raw)
            if m:
                dt = self._parse_naive(
                    m.group(1),
                    int(m.group(2)),
                    self._zone_for_token(m.group(3), m.group(1)),
                )
                rest = raw[m.end() :]
                sev = _PG_SEVERITY.match(rest)
                level = _PG_LEVELS.get(sev.group(1) if sev else b"")
                if level is None:
                    level = self._pg_level
                else:
                    self._pg_level = level
                return (
                    f"{self._render(dt)} ".encode()
                    + level
                    + b" postgres "
                    + m.group(4)
                    + rest
                )
            m = _NGX_ERR.match(raw)
            if m:
                dt = self._parse_naive(m.group(1), 0, self._pid1_zone, "%Y/%m/%d %H:%M:%S")
                level = _NGX_LEVELS.get(m.group(2)[1:-2], b"INFO")
                return (
                    f"{self._render(dt)} ".encode()
                    + level
                    + b" nginx.error "
                    + m.group(2)
                    + raw[m.end() :]
                )
            m = _NGX_ACC.match(raw)
            if m:
                dt = datetime.strptime(
                    (m.group(2) + b" " + m.group(3)).decode(),
                    "%d/%b/%Y:%H:%M:%S %z",
                )
                return (
                    f"{self._render(dt)} INFO nginx.access ".encode()
                    + m.group(1)
                    + b" "
                    + raw[m.end() :]
                )
            return None
        except Exception:
            # A parse surprise leaves the line untouched, still a record.
            return raw

    def _forward(self, line):
        # Blocking write: the forwarded stream never drops.
        try:
            view = memoryview(line)
            while view:
                view = view[os.write(self.out_fd, view) :]
        except OSError:
            pass

    # ── writer thread: batches, markers, rotation ─────────────────────────

    def writer(self):
        while True:
            self._wake.wait(_FLUSH_INTERVAL_SECONDS)
            self._wake.clear()
            if self._conf_is_stale():
                self._apply_conf()
            try:
                self._drain()
            except OSError:
                time.sleep(1.0)
            if self._stop:
                try:
                    self._drain()
                except OSError:
                    pass
                self._close_fd()
                self._remove_pidfile()
                return

    def _conf_is_stale(self):
        # Polled, not signalled, so a save in another container lands too. The
        # first poll is one tick in: until then records carry the boot zone,
        # which is the price of the reader owning stdin before any file work.
        return self._reload or self._conf_stat() != self._conf_stamp

    def _conf_stat(self):
        # A save in another container cannot signal this one; the conf can.
        try:
            st = os.stat(conf_path(self.log_dir))
        except OSError:
            return None
        return (st.st_mtime_ns, st.st_size)

    def _apply_conf(self):
        self._reload = False
        # Stamped before the read, so a write that races it is caught next tick.
        self._conf_stamp = self._conf_stat()
        # Conf first: _setup_fs only announces itself when the file sink is on.
        self.conf = read_conf(self.log_dir)
        self._setup_fs()
        try:
            self._display_zone = ZoneInfo(str(self.conf["time_zone"]).strip())
        except (KeyError, ValueError):
            self._display_zone = _boot_display_zone()
        self._container_zone = _resolve_container_zone()
        self._pid1_zone = _resolve_pid1_zone(self._container_zone)
        self._prune()

    def _setup_fs(self):
        # All filesystem setup is tolerant and retried on every reload, so a
        # dead /data degrades to drain-and-drop instead of a crash loop.
        try:
            os.makedirs(_config_dir(self.log_dir), exist_ok=True)
            with open(pid_path(self.log_dir), "w", encoding="utf-8") as f:
                f.write(str(os.getpid()))
            if not self._fs_ready and self.conf["persist"]:
                # Only when something will actually be filed: a start line in an
                # otherwise-empty file makes the boot archive shift promote a
                # whole rotation of stubs.
                self._fs_ready = True
                self._enqueue(
                    f"{self._now_stamp()} INFO dispatcharr.log_collector started\n".encode()
                )
        except OSError:
            pass

    def _remove_pidfile(self):
        try:
            os.remove(pid_path(self.log_dir))
        except OSError:
            pass

    def _enqueue(self, data):
        with self._lock:
            self._buf.append(data)
            self._buf_bytes += len(data)

    def _drain(self):
        while not self._reload:
            with self._lock:
                batch, batch_bytes = [], 0
                while self._buf and batch_bytes < _BATCH_BYTES:
                    item = self._buf.popleft()
                    batch.append(item)
                    batch_bytes += len(item)
                self._buf_bytes -= batch_bytes
                dropped, self._dropped = self._dropped, 0
            # A marker or rotation must not splice into an unterminated line.
            marker_count = 0
            if dropped and not self._tail_open:
                marker = (
                    f"{self._now_stamp()} WARNING dispatcharr.log_collector {dropped} "
                    f"log lines dropped (buffer full - slow disk or log burst)\n"
                ).encode("utf-8", "replace")
                batch.insert(0, marker)
                marker_count = dropped
            elif dropped:
                with self._lock:
                    self._dropped += dropped
            if not batch:
                return
            if batch:
                try:
                    self._write_batch(batch)
                except _WriteFailure as failure:
                    self._requeue(batch, failure.written, marker_count)
                    raise failure.cause
            if not self._tail_open:
                self._maybe_rotate()

    def _requeue(self, batch, written, marker_count=0):
        # Requeue only the unwritten tail; a torn item stays whole, so its
        # flushed prefix repeats on retry. An unwritten marker folds back into
        # the counter so eviction can never lose it.
        idx = 0
        for item in batch:
            if written < len(item):
                break
            written -= len(item)
            idx += 1
        remainder = batch[idx:]
        with self._lock:
            if marker_count and idx == 0 and remainder:
                remainder = remainder[1:]
                self._dropped += marker_count
            self._buf.extendleft(reversed(remainder))
            self._buf_bytes += sum(len(i) for i in remainder)

    def _write_batch(self, batch):
        data = b"".join(batch)
        written = 0
        try:
            if self._fd is None:
                self._fd = os.open(
                    self.live_path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644
                )
            try:
                os.stat(self.live_path)
            except FileNotFoundError:
                self._close_fd()
                self._fd = os.open(
                    self.live_path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644
                )
            view = memoryview(data)
            while view:
                n = os.write(self._fd, view)
                view = view[n:]
                written += n
            self._tail_open = not data.endswith(b"\n")
        except OSError as exc:
            prefix = data[:written]
            self._tail_open = bool(prefix) and not prefix.endswith(b"\n")
            raise _WriteFailure(written, exc) from exc

    def _maybe_rotate(self):
        max_bytes = self.conf["max_mb"] * 1024 * 1024
        try:
            size = os.path.getsize(self.live_path)
        except OSError:
            return
        if size <= max_bytes:
            return
        self._close_fd()
        try:
            for n in sorted(self._archive_indices(), reverse=True):
                if n + 1 >= self.conf["keep"]:
                    os.remove(f"{self.live_path}.{n}")
                else:
                    os.replace(f"{self.live_path}.{n}", f"{self.live_path}.{n + 1}")
            os.replace(self.live_path, f"{self.live_path}.1")
            # Recreate immediately so the viewer never sees the live file missing.
            os.close(os.open(self.live_path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644))
        except OSError:
            return

    def _prune(self):
        # Runs on every conf apply: boot-shift archives and a lowered keep
        # must converge without waiting for a size-cap rotation.
        try:
            for n in self._archive_indices():
                if n >= self.conf["keep"]:
                    os.remove(f"{self.live_path}.{n}")
        except OSError:
            pass

    def _archive_indices(self):
        indices = []
        prefix = LIVE_NAME + "."
        try:
            names = os.listdir(self.log_dir)
        except OSError:
            return indices
        for name in names:
            if name.startswith(prefix) and name[len(prefix) :].isdigit():
                indices.append(int(name[len(prefix) :]))
        return indices

    def _close_fd(self):
        if self._fd is not None:
            try:
                os.close(self._fd)
            except OSError:
                pass
            self._fd = None

    def run(self, stream):
        # Signals first, then the reader owns stdin before any filesystem
        # work: a dead /data must never leave the pipe undrained. The clock
        # zones live on the root filesystem, so resolving them here cannot block.
        self.install_signals()
        self._container_zone = _resolve_container_zone()
        self._pid1_zone = _resolve_pid1_zone(self._container_zone)
        reader = threading.Thread(target=self.reader, args=(stream,), name="log-collector-reader")
        reader.start()
        self.writer()
        reader.join(timeout=5.0)


def main(argv):
    if len(argv) != 2:
        print("usage: python -m dispatcharr.log_collector <logdir>", file=sys.stderr)
        return 2
    Collector(argv[1]).run(sys.stdin.buffer)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
