"""Single-flight Redis chunk cache for large streaming HTTP responses."""

import logging
import time

from django.http import StreamingHttpResponse

logger = logging.getLogger(__name__)

STATUS_BUILDING = "building"
STATUS_READY = "ready"
STATUS_ERROR = "error"

DEFAULT_CACHE_TTL = 300
DEFAULT_LOCK_TTL = 120
DEFAULT_POLL_INTERVAL = 0.05
DEFAULT_MAX_FOLLOWER_WAIT = 600

EPG_CACHE_GENERATION_KEY = "epg_content_generation"


def _chunks_key(base_key):
    return f"{base_key}:chunks"


def _ready_key(base_key):
    return f"{base_key}:ready"


def _status_key(base_key):
    return f"{base_key}:status"


def _lock_key(base_key):
    return f"{base_key}:lock"


def _decode_chunk(chunk):
    if chunk is None:
        return None
    if isinstance(chunk, bytes):
        return chunk.decode("utf-8")
    return chunk


def _encode_chunk(chunk):
    if isinstance(chunk, bytes):
        return chunk
    return chunk.encode("utf-8")


def _poll_wait(interval):
    try:
        from core.utils import _is_gevent_monkey_patched

        if _is_gevent_monkey_patched():
            import gevent

            gevent.sleep(interval)
            return
    except ImportError:
        pass
    time.sleep(interval)


def _get_redis():
    from django_redis import get_redis_connection

    return get_redis_connection("default")


def _get_status(redis, base_key):
    raw = redis.get(_status_key(base_key))
    if raw is None:
        return None
    return _decode_chunk(raw)


def _clear_build_keys(redis, base_key):
    redis.delete(
        _chunks_key(base_key),
        _status_key(base_key),
        _ready_key(base_key),
        _lock_key(base_key),
    )


def _try_acquire_lock(redis, base_key, lock_ttl):
    return bool(redis.set(_lock_key(base_key), "1", nx=True, ex=lock_ttl))


def _refresh_build_ttl(redis, base_key, lock_ttl):
    redis.expire(_lock_key(base_key), lock_ttl)
    redis.expire(_status_key(base_key), lock_ttl)
    redis.expire(_chunks_key(base_key), lock_ttl)


def _refresh_ready_ttl(redis, base_key, cache_ttl):
    redis.expire(_chunks_key(base_key), cache_ttl)
    redis.expire(_status_key(base_key), cache_ttl)
    redis.expire(_ready_key(base_key), cache_ttl)


def _stream_ready(redis, base_key, cache_ttl):
    chunks_key = _chunks_key(base_key)
    refresh_interval = max(1, cache_ttl // 4)
    _refresh_ready_ttl(redis, base_key, cache_ttl)
    last_refresh = time.monotonic()
    offset = 0
    while True:
        now = time.monotonic()
        if now - last_refresh >= refresh_interval:
            _refresh_ready_ttl(redis, base_key, cache_ttl)
            last_refresh = now
        chunk = redis.lindex(chunks_key, offset)
        if chunk is None:
            break
        yield _decode_chunk(chunk)
        offset += 1


def _stream_build(redis, base_key, source, cache_ttl, lock_ttl):
    """Leader: stream to client and append each chunk to Redis."""
    chunks_key = _chunks_key(base_key)
    status_key = _status_key(base_key)
    try:
        from django.core.cache import cache as django_cache

        django_cache.delete(base_key)  # clear any non-chunked entry under this key
        redis.delete(chunks_key, _ready_key(base_key))
        redis.set(status_key, STATUS_BUILDING, ex=lock_ttl)
        refresh_interval = max(1, lock_ttl // 4)
        last_refresh = 0.0
        from core.utils import _cooperative_yield

        for chunk in source():
            redis.rpush(chunks_key, _encode_chunk(chunk))
            now = time.monotonic()
            if now - last_refresh >= refresh_interval:
                _refresh_build_ttl(redis, base_key, lock_ttl)
                last_refresh = now
            _cooperative_yield()
            yield chunk
        redis.set(status_key, STATUS_READY)
        redis.set(_ready_key(base_key), "1")
        redis.expire(chunks_key, cache_ttl)
        redis.expire(status_key, cache_ttl)
        redis.expire(_ready_key(base_key), cache_ttl)
        logger.debug("Cached response in %s chunks", redis.llen(chunks_key))
    except Exception:
        logger.exception("Chunk cache build failed for %s", base_key)
        redis.delete(chunks_key)
        redis.set(status_key, STATUS_ERROR, ex=60)
        raise
    finally:
        redis.delete(_lock_key(base_key))


def _stream_follow(redis, base_key, source, cache_ttl, lock_ttl, poll_interval, max_follower_wait):
    """Follower: read chunks as the leader writes them."""
    offset = 0
    deadline = time.monotonic() + max_follower_wait
    idle_polls = 0
    chunks_key = _chunks_key(base_key)
    lock_key = _lock_key(base_key)
    refresh_interval = max(1, cache_ttl // 4)
    last_refresh = 0.0

    while True:
        chunk = redis.lindex(chunks_key, offset)
        if chunk is not None:
            idle_polls = 0
            now = time.monotonic()
            if now - last_refresh >= refresh_interval:
                _refresh_ready_ttl(redis, base_key, cache_ttl)
                last_refresh = now
            yield _decode_chunk(chunk)
            offset += 1
            continue

        status = _get_status(redis, base_key)
        if status == STATUS_READY:
            break

        if status == STATUS_ERROR:
            _clear_build_keys(redis, base_key)
            if offset == 0 and _try_acquire_lock(redis, base_key, lock_ttl):
                yield from _stream_build(redis, base_key, source, cache_ttl, lock_ttl)
                return
            raise RuntimeError("Chunk cache build failed")

        if time.monotonic() >= deadline:
            if offset == 0 and _try_acquire_lock(redis, base_key, lock_ttl):
                logger.warning("Chunk cache follower timed out; rebuilding %s", base_key)
                yield from _stream_build(redis, base_key, source, cache_ttl, lock_ttl)
                return
            logger.warning("Chunk cache follower timed out after partial read for %s", base_key)
            break

        lock_active = bool(redis.exists(lock_key))
        if status != STATUS_BUILDING and not lock_active:
            idle_polls += 1
            if offset == 0 and idle_polls >= max(1, int(1.0 / poll_interval)):
                if _try_acquire_lock(redis, base_key, lock_ttl):
                    logger.warning("Chunk cache leader lost; rebuilding %s", base_key)
                    yield from _stream_build(redis, base_key, source, cache_ttl, lock_ttl)
                    return
        else:
            idle_polls = 0

        _poll_wait(poll_interval)


def stream_cached_response(
    cache_key,
    source,
    *,
    content_type="application/xml",
    filename=None,
    cache_ttl=DEFAULT_CACHE_TTL,
    lock_ttl=DEFAULT_LOCK_TTL,
    poll_interval=DEFAULT_POLL_INTERVAL,
    max_follower_wait=DEFAULT_MAX_FOLLOWER_WAIT,
    redis=None,
    generation_key=None,
):
    """
    Stream a large response with single-flight Redis chunk caching.

    ``source`` must be a callable returning a chunk iterator. Only the leader
    invokes it; concurrent followers replay chunks already written to Redis, so
    the expensive ``source`` runs at most once per ``cache_key``.

    If ``generation_key`` is given, the current value of that Redis counter is
    appended to ``cache_key``; incrementing the counter retires every entry
    without touching builds or reads that are still in flight.
    """
    if redis is None:
        redis = _get_redis()

    if generation_key:
        generation = _decode_chunk(redis.get(generation_key)) or "0"
        cache_key = f"{cache_key}:g={generation}"

    if redis.get(_ready_key(cache_key)):
        logger.debug("Serving response from chunk cache")
        stream = _stream_ready(redis, cache_key, cache_ttl)
    else:
        status = _get_status(redis, cache_key)
        if status == STATUS_ERROR:
            _clear_build_keys(redis, cache_key)

        if _try_acquire_lock(redis, cache_key, lock_ttl):
            logger.debug("Building response (cache leader)")
            stream = _stream_build(redis, cache_key, source, cache_ttl, lock_ttl)
        else:
            logger.debug("Following in-flight cache build")
            stream = _stream_follow(
                redis,
                cache_key,
                source,
                cache_ttl,
                lock_ttl,
                poll_interval,
                max_follower_wait,
            )

    response = StreamingHttpResponse(stream, content_type=content_type)
    if filename:
        response["Content-Disposition"] = f'attachment; filename="{filename}"'
    response["Cache-Control"] = "no-cache"
    return response


def invalidate_epg_chunk_cache():
    """
    Retire all XMLTV /output/epg chunk-cache entries.

    EPG assignment changes (channel or override), programme imports, and
    finished EPG refreshes (XMLTV and Schedules Direct) do not change the
    cache params, so without this the next /output/epg can keep serving stale
    programmes for up to DEFAULT_CACHE_TTL while the in-app guide (uncached)
    is already correct. M3U refreshes that rewrite channels also call this so
    channel names, numbers, and logos in the XMLTV channel list stay current.

    Advances the cache generation instead of deleting keys: a build that is
    still streaming keeps writing to its own (now unreachable) key, so it can
    never publish a partial chunk list, and in-flight readers are not cut off.
    Retired entries expire on their existing TTLs.
    """
    try:
        _get_redis().incr(EPG_CACHE_GENERATION_KEY)
    except Exception:
        logger.warning("Failed to invalidate EPG chunk cache", exc_info=True)


def invalidate_m3u_content_cache():
    """
    Drop Django-cache M3U playlist entries (`m3u_content:*`).

    Channel list, names, numbers, logos, and stream URLs can change when an
    M3U account finishes refreshing (including auto channel sync). The playlist
    cache key does not include those inputs, so clear it on refresh completion.
    """
    try:
        from django.core.cache import cache

        delete_pattern = getattr(cache, "delete_pattern", None)
        if not callable(delete_pattern):
            logger.warning(
                "Cache backend has no delete_pattern; skipping M3U content cache invalidate"
            )
            return
        deleted = delete_pattern("m3u_content:*")
        if deleted:
            logger.debug("Invalidated %s m3u_content cache key(s)", deleted)
    except Exception:
        logger.warning("Failed to invalidate M3U content cache", exc_info=True)


def invalidate_output_caches_after_m3u_refresh():
    """Clear M3U playlist and XMLTV caches after a successful M3U refresh."""
    invalidate_m3u_content_cache()
    invalidate_epg_chunk_cache()
