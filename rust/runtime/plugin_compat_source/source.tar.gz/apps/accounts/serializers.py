import json
import re

from rest_framework import serializers
from django.contrib.auth.models import Group, Permission
from .models import User
from apps.channels.models import ChannelProfile


# Valid navigation item IDs for validation
VALID_NAV_ITEM_IDS = {
    'channels', 'vods', 'sources', 'guide', 'dvr',
    'stats', 'plugins', 'integrations', 'system', 'settings'
}
MAX_CUSTOM_PROPS_SIZE = 102400  # 100KB limit
SAFE_CREDENTIAL_RE = re.compile(r"^[A-Za-z0-9._@-]+$")


def validate_nav_array(value, field_name):
    """Validate that a value is an array of valid nav item ID strings."""
    if not isinstance(value, list):
        raise serializers.ValidationError(f"{field_name} must be an array")
    if len(value) > 50:
        raise serializers.ValidationError(f"{field_name} exceeds maximum length of 50 items")
    for item in value:
        if not isinstance(item, str):
            raise serializers.ValidationError(f"{field_name} items must be strings")
        if item not in VALID_NAV_ITEM_IDS:
            raise serializers.ValidationError(f"'{item}' is not a valid navigation item ID")


# 🔹 Fix for Permission serialization
class PermissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Permission
        fields = ["id", "name", "codename"]


# 🔹 Fix for Group serialization
class GroupSerializer(serializers.ModelSerializer):
    permissions = serializers.PrimaryKeyRelatedField(
        many=True, queryset=Permission.objects.all()
    )  # ✅ Fixes ManyToManyField `_meta` error

    class Meta:
        model = Group
        fields = ["id", "name", "permissions"]


# 🔹 Fix for User serialization
class UserSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=False)
    channel_profiles = serializers.PrimaryKeyRelatedField(
        queryset=ChannelProfile.objects.all(), many=True, required=False
    )
    api_key = serializers.CharField(read_only=True, allow_null=True)

    class Meta:
        model = User
        fields = [
            "id",
            "username",
            "api_key",
            "email",
            "user_level",
            "password",
            "channel_profiles",
            "custom_properties",
            "avatar_config",
            "stream_limit",
            "is_staff",
            "is_superuser",
            "last_login",
            "date_joined",
            "first_name",
            "last_name",
        ]

    def validate_username(self, value):
        if not SAFE_CREDENTIAL_RE.fullmatch(value):
            raise serializers.ValidationError(
                "Username may only contain letters, numbers, periods (.), underscores (_), at signs (@), and hyphens (-)"
            )
        return value

    def validate_custom_properties(self, value):
        """Validate custom_properties structure and size."""
        if value is None:
            return {}
        if not isinstance(value, dict):
            raise serializers.ValidationError("custom_properties must be a dictionary")

        # Size limit check
        try:
            if len(json.dumps(value)) > MAX_CUSTOM_PROPS_SIZE:
                raise serializers.ValidationError(
                    f"custom_properties exceeds maximum size of {MAX_CUSTOM_PROPS_SIZE} bytes"
                )
        except (TypeError, ValueError):
            raise serializers.ValidationError("custom_properties contains non-serializable data")

        # Validate navOrder if present
        if 'navOrder' in value:
            validate_nav_array(value['navOrder'], 'navOrder')

        # Validate hiddenNav if present
        if 'hiddenNav' in value:
            validate_nav_array(value['hiddenNav'], 'hiddenNav')

        xc_password = value.get("xc_password")

        if xc_password and not SAFE_CREDENTIAL_RE.fullmatch(xc_password):
            raise serializers.ValidationError(
                "XC password may only contain letters, numbers, periods (.), underscores (_), at signs (@), and hyphens (-)"
            )

        allowed_m3u_profile_ids = value.get("allowed_m3u_profile_ids")
        if allowed_m3u_profile_ids is not None and (
            not isinstance(allowed_m3u_profile_ids, list)
            or any(
                not isinstance(profile_id, int) or isinstance(profile_id, bool) or profile_id <= 0
                for profile_id in allowed_m3u_profile_ids
            )
        ):
            raise serializers.ValidationError(
                "allowed_m3u_profile_ids must be a list of positive integer IDs"
            )

        return value

    def create(self, validated_data):
        channel_profiles = validated_data.pop("channel_profiles", [])

        user = User(**validated_data)
        user.set_password(validated_data["password"])
        user.save()

        user.channel_profiles.set(channel_profiles)

        return user

    def update(self, instance, validated_data):
        password = validated_data.pop("password", None)
        channel_profiles = validated_data.pop("channel_profiles", None)

        # Merge custom_properties instead of replacing (prevents data loss)
        # null values are explicit deletions; all other values overwrite existing
        custom_properties = validated_data.pop("custom_properties", None)
        if custom_properties is not None:
            existing = instance.custom_properties or {}
            merged = dict(existing)
            for k, v in custom_properties.items():
                if v is None:
                    merged.pop(k, None)
                else:
                    merged[k] = v
            # Scrub stale nav IDs so the DB self-heals on next save
            for nav_field in ('navOrder', 'hiddenNav'):
                if nav_field in merged and isinstance(merged[nav_field], list):
                    merged[nav_field] = [
                        item for item in merged[nav_field]
                        if item in VALID_NAV_ITEM_IDS
                    ]
            instance.custom_properties = merged

        for attr, value in validated_data.items():
            setattr(instance, attr, value)

        if password:
            instance.set_password(password)

        instance.save()

        if channel_profiles is not None:
            instance.channel_profiles.set(channel_profiles)

        return instance


class ProxyLoginResponseSerializer(serializers.Serializer):
    """JWT pair returned by the reverse proxy sign-in endpoint."""

    access = serializers.CharField()
    refresh = serializers.CharField()


class AppDataLimitsSerializer(serializers.Serializer):
    max_value_bytes = serializers.IntegerField()
    max_total_bytes = serializers.IntegerField()
    max_apps = serializers.IntegerField()
    max_depth = serializers.IntegerField()
    key_min_length = serializers.IntegerField()
    key_max_length = serializers.IntegerField()


class AppDataAppSummarySerializer(serializers.Serializer):
    key = serializers.CharField(
        help_text="App namespace (8 to 64 chars: [A-Za-z0-9][A-Za-z0-9._-]*)"
    )
    bytes = serializers.IntegerField(
        help_text="Compact UTF-8 JSON size of that app's stored object"
    )


class AppDataListResponseSerializer(serializers.Serializer):
    """GET .../app-data/ list payload (keys and sizes only, never values)."""

    limits = AppDataLimitsSerializer()
    total_bytes = serializers.IntegerField()
    apps = AppDataAppSummarySerializer(many=True)


class AppDataDetailErrorSerializer(serializers.Serializer):
    detail = serializers.CharField(
        help_text="Human-readable error message"
    )
    code = serializers.CharField(
        help_text=(
            "Stable machine-readable identifier, for example "
            "key_invalid, key_not_found, value_too_large, "
            "total_too_large, max_apps, forbidden, user_not_found"
        )
    )
