from apps.epg.sd_utils import (
    sd_clear_cached_token,
    sd_credential_fingerprint,
)
from apps.epg.utils import sd_poster_proxy_path
from core.utils import validate_flexible_url, build_absolute_uri_with_port
from rest_framework import serializers
from .models import EPGSource, EPGData, ProgramData
from apps.channels.access import channels_queryset_for_user, is_admin_user
from apps.channels.models import Channel, Stream

class EPGSourceSerializer(serializers.ModelSerializer):
    epg_data_count = serializers.SerializerMethodField()
    has_channels = serializers.BooleanField(read_only=True, default=False)
    read_only_fields = ['created_at', 'updated_at']
    url = serializers.CharField(
        required=False,
        allow_blank=True,
        allow_null=True,
        validators=[validate_flexible_url]
    )
    cron_expression = serializers.CharField(required=False, allow_blank=True, default='')

    class Meta:
        model = EPGSource
        fields = [
            'id',
            'name',
            'source_type',
            'url',
            'username',
            'password',
            'is_active',
            'file_path',
            'refresh_interval',
            'cron_expression',
            'priority',
            'status',
            'last_message',
            'created_at',
            'updated_at',
            'custom_properties',
            'epg_data_count',
            'has_channels',
        ]
        extra_kwargs = {'password': {'write_only': True}}

    def get_epg_data_count(self, obj):
        """Return the count of EPG data entries instead of all IDs to prevent large payloads"""
        return obj.epgs.count()

    def to_representation(self, instance):
        data = super().to_representation(instance)
        # Derive cron_expression from the linked PeriodicTask's crontab (single source of truth)
        # But first check if we have a transient _cron_expression (from create/update before signal runs)
        cron_expr = ''
        if hasattr(instance, '_cron_expression'):
            cron_expr = instance._cron_expression
        elif instance.refresh_task_id and instance.refresh_task and instance.refresh_task.crontab:
            ct = instance.refresh_task.crontab
            cron_expr = f'{ct.minute} {ct.hour} {ct.day_of_month} {ct.month_of_year} {ct.day_of_week}'
        data['cron_expression'] = cron_expr
        return data

    def update(self, instance, validated_data):
        # Pop cron_expression before it reaches model fields
        # If not present (partial update), preserve the existing cron from the PeriodicTask
        if 'cron_expression' in validated_data:
            cron_expr = validated_data.pop('cron_expression')
        else:
            cron_expr = ''
            if instance.refresh_task_id and instance.refresh_task and instance.refresh_task.crontab:
                ct = instance.refresh_task.crontab
                cron_expr = f'{ct.minute} {ct.hour} {ct.day_of_month} {ct.month_of_year} {ct.day_of_week}'
        instance._cron_expression = cron_expr
        prior_fp = sd_credential_fingerprint(instance.username, instance.password)
        for attr, value in validated_data.items():
            if attr == 'password' and not value:
                continue
            setattr(instance, attr, value)
        instance.save()
        # Drop any Redis SD session tied to the previous username/password so
        # poster traffic cannot keep using another account's token.
        if prior_fp != sd_credential_fingerprint(instance.username, instance.password):
            sd_clear_cached_token(instance.id)
        return instance

    def create(self, validated_data):
        cron_expr = validated_data.pop('cron_expression', '')
        instance = EPGSource(**validated_data)
        instance._cron_expression = cron_expr
        instance.save()
        return instance

class ProgramDataSerializer(serializers.ModelSerializer):

    class Meta:
        model = ProgramData
        fields = ['id', 'start_time', 'end_time', 'title', 'sub_title', 'description', 'tvg_id']

    def to_representation(self, obj):
        data = super().to_representation(obj)
        cp = obj.custom_properties or {}
        data['season'] = cp.get('season')
        data['episode'] = cp.get('episode')
        data['is_new'] = bool(cp.get('new'))
        data['is_live'] = bool(cp.get('live'))
        data['is_premiere'] = bool(cp.get('premiere'))
        premiere_text = cp.get('premiere_text', '')
        data['is_finale'] = bool(premiere_text and 'finale' in premiere_text.lower())
        return data


class EPGGridProgramSerializer(serializers.Serializer):
    """One programme object in ``GET /api/epg/grid/``.

    Matches the streamed JSON fields. ``custom_properties`` is present on
    dummy programmes only (null when empty) and omitted for stored rows.
    """

    id = serializers.CharField(
        help_text=(
            "Stored programme primary key, or a synthetic dummy id "
            "(prefix-channelId-YYYYMMDDTHHMMSS)."
        )
    )
    start_time = serializers.DateTimeField()
    end_time = serializers.DateTimeField()
    title = serializers.CharField(allow_null=True, required=False)
    sub_title = serializers.CharField(allow_null=True, required=False)
    description = serializers.CharField(allow_null=True, required=False)
    tvg_id = serializers.CharField(allow_null=True, required=False)
    season = serializers.IntegerField(allow_null=True, required=False)
    episode = serializers.IntegerField(allow_null=True, required=False)
    is_new = serializers.BooleanField()
    is_live = serializers.BooleanField()
    is_premiere = serializers.BooleanField()
    is_finale = serializers.BooleanField()
    custom_properties = serializers.JSONField(
        required=False,
        allow_null=True,
        help_text="Present on dummy programmes only. Null when empty.",
    )


class EPGGridResponseSerializer(serializers.Serializer):
    """Envelope for ``GET /api/epg/grid/``."""

    data = EPGGridProgramSerializer(many=True)


class ProgramDetailSerializer(ProgramDataSerializer):
    """Rich serializer for program detail view — extends slim serializer with full custom_properties."""

    def to_representation(self, obj):
        data = super().to_representation(obj)
        cp = obj.custom_properties or {}

        # Categories
        data['categories'] = cp.get('categories') or []

        # Content rating
        data['rating'] = cp.get('rating')
        data['rating_system'] = cp.get('rating_system')

        # Star ratings
        data['star_ratings'] = cp.get('star_ratings') or []

        # Credits — flatten from XMLTV structure
        credits = cp.get('credits') or {}
        data['credits'] = {
            'actors': credits.get('actor') or [],
            'directors': credits.get('director') or [],
            'writers': credits.get('writer') or [],
            'producers': credits.get('producer') or [],
            'presenters': credits.get('presenter') or [],
        }

        # Video/audio quality
        video = cp.get('video') or {}
        data['video_quality'] = video.get('quality')
        data['aspect_ratio'] = video.get('aspect')

        audio = cp.get('audio') or {}
        data['stereo'] = audio.get('stereo')

        # Previously shown (rerun)
        data['is_previously_shown'] = bool(cp.get('previously_shown'))

        # Geographic/language
        data['country'] = cp.get('country')
        data['language'] = cp.get('language')

        # Dates
        data['production_date'] = cp.get('date')
        previously_shown = cp.get('previously_shown_details') or {}
        data['original_air_date'] = previously_shown.get('start')

        # Content advisory (SD)
        data['content_advisory'] = cp.get('content_advisory') or []

        # Full content ratings array (SD — all regional ratings)
        data['content_ratings'] = cp.get('content_ratings') or []

        # Sports event details (SD)
        data['event_details'] = cp.get('event_details')

        # Runtime (duration without commercials)
        length = cp.get('length') or {}
        data['runtime'] = length.get('value') if length else None
        data['runtime_units'] = length.get('units') if length else None

        # External IDs
        data['imdb_id'] = cp.get('imdb.com_id')
        data['tmdb_id'] = cp.get('themoviedb.org_id')
        data['tvdb_id'] = cp.get('thetvdb.com_id')

        # Images
        data['icon'] = cp.get('icon')
        data['images'] = cp.get('images') or []

        # SD poster: expose as absolute proxy URL so frontend/img tags never need SD auth.
        # ``?v=`` tracks the sd_icon URI so nginx/browser caches bust when artwork changes.
        sd_icon = cp.get('sd_icon')
        if sd_icon:
            poster_path = sd_poster_proxy_path(obj.id, sd_icon)
            request = self.context.get('request')
            if request:
                data['poster_url'] = build_absolute_uri_with_port(request, poster_path)
            else:
                data['poster_url'] = poster_path
        else:
            data['poster_url'] = None

        return data


class EPGDataSerializer(serializers.ModelSerializer):
    """
    Only returns the tvg_id and the 'name' field from EPGData.
    We assume 'name' is effectively the channel name.
    """
    read_only_fields = ['epg_source']

    class Meta:
        model = EPGData
        fields = [
            'id',
            'tvg_id',
            'name',
            'icon_url',
            'epg_source',
        ]


class ProgramSearchChannelSerializer(serializers.Serializer):
    """Lightweight channel info for search results (override-aware)."""

    id = serializers.IntegerField()
    name = serializers.SerializerMethodField()
    channel_number = serializers.SerializerMethodField()
    channel_group = serializers.SerializerMethodField()
    tvg_id = serializers.SerializerMethodField()

    def get_name(self, obj):
        value = getattr(obj, "effective_name", None)
        return obj.name if value is None else value

    def get_channel_number(self, obj):
        value = getattr(obj, "effective_channel_number", None)
        return value if value is not None else obj.channel_number

    def get_channel_group(self, obj):
        group = getattr(obj, "effective_channel_group_obj", None)
        if group is None:
            group = getattr(obj, "channel_group", None)
        return group.name if group is not None else None

    def get_tvg_id(self, obj):
        value = getattr(obj, "effective_tvg_id", None)
        return value if value is not None else obj.tvg_id


class ProgramSearchStreamSerializer(serializers.ModelSerializer):
    """Lightweight stream info for search results."""
    channel_group = serializers.CharField(source='channel_group.name', default=None)
    m3u_account = serializers.CharField(source='m3u_account.name', default=None)

    class Meta:
        model = Stream
        fields = ['id', 'name', 'channel_group', 'tvg_id', 'm3u_account']


class ProgramSearchResultSerializer(serializers.ModelSerializer):
    """Full program data with associated channels and streams for search results."""
    epg_source = serializers.CharField(source='epg.epg_source.name', default=None)
    epg_name = serializers.CharField(source='epg.name', default=None)
    epg_icon_url = serializers.URLField(source='epg.icon_url', default=None)
    channels = serializers.SerializerMethodField()
    streams = serializers.SerializerMethodField()

    class Meta:
        model = ProgramData
        fields = [
            'id', 'title', 'sub_title', 'description',
            'start_time', 'end_time', 'tvg_id', 'custom_properties',
            'epg_source', 'epg_name', 'epg_icon_url',
            'channels', 'streams',
        ]

    def _accessible_channels(self, obj):
        """Return channels effectively mapped to this program's EPG.

        Prefer the bulk map built by the search view (includes override-only
        EPG assignments and applies user access once). Fall back to the
        reverse FK for callers that do not supply the map.
        """
        by_epg = self.context.get("channels_by_epg_id")
        if by_epg is not None:
            return by_epg.get(obj.epg_id, [])

        channels = list(obj.epg.channels.all()) if obj.epg else []
        user = self.context.get("user")
        if (
            not channels
            or user is None
            or not getattr(user, "is_authenticated", False)
            or is_admin_user(user)
        ):
            return channels
        visible = set(
            channels_queryset_for_user(
                Channel.objects.filter(pk__in=[ch.pk for ch in channels]),
                user,
            ).values_list("pk", flat=True)
        )
        return [ch for ch in channels if ch.pk in visible]

    def get_channels(self, obj):
        fields = self.context.get('fields')
        if fields is not None and 'channels' not in fields:
            return []
        return ProgramSearchChannelSerializer(self._accessible_channels(obj), many=True).data

    def get_streams(self, obj):
        fields = self.context.get('fields')
        if fields is not None and 'streams' not in fields:
            return []
        stream_ids = set()
        streams = []
        for ch in self._accessible_channels(obj):
            for s in ch.streams.all():
                if s.id not in stream_ids:
                    stream_ids.add(s.id)
                    streams.append(s)
        return ProgramSearchStreamSerializer(streams, many=True).data
