import datetime,hashlib,json,os,signal,subprocess,time
from pathlib import Path
ROOT=Path('/home/justin/github/Dispatcharr');HERE=Path(__file__).resolve().parent;PLAN=ROOT/'artifacts/rust/m5-notification-credential-source-executor-1';OUTPUT=ROOT/'artifacts/rust/m5-notification-credential-source-1';SEAL='9c09896c7cc71d57ff152bb3fc4c93d5bd158179da7b136c0e23c96c38e4c9fc'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def proc(pid):
 try:return Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()[19]
 except FileNotFoundError:return None
def save(name,v):(HERE/name).write_text(json.dumps(v,indent=2)+'\n')
assert hashlib.sha256((PLAN/'seal.json').read_bytes()).hexdigest()==SEAL;assert not OUTPUT.exists();argv=['python',str(PLAN/'controller/run.py'),'--execute-reviewed-seal',SEAL,'--output',str(OUTPUT)]
with(HERE/'controller.stdout').open('xb')as stdout,(HERE/'controller.stderr').open('xb')as stderr:
 p=subprocess.Popen(argv,cwd=ROOT,env=dict({k:v for k,v in os.environ.items()if not k.startswith('GIT_')},PYTHONUNBUFFERED='1'),stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True);row={'state':'RUNNING','argv':argv,'pid':p.pid,'starttime':proc(p.pid),'started_utc':now(),'seal_sha256':SEAL,'stdin':'DEVNULL','stdout_stderr':'owned regular files; no host pipe readers'};save('host-process.json',row);print(json.dumps(row),flush=True)
 try:code=p.wait(timeout=1500)
 except BaseException:
  row['wrapper_exception']=True
  if p.poll()is None:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=30)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=10)
  raise
 finally:row.update(state='SETTLED',actual_wait=p.returncode,actual_poll=p.poll(),after_starttime=proc(p.pid),settled_utc=now());save('host-process.json',row)
print(json.dumps(row),flush=True)
raise SystemExit(code)
